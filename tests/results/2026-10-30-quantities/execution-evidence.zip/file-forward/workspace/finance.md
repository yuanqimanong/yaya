# 季度说明 {#quarter}

本季度收入为 USD 5 million，数据未经审计。毛利率提高 3 个百分点。预计下季度收入为 EUR 6 million，预测尚未经过审计。
