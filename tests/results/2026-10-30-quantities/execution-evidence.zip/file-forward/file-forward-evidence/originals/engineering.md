# Runtime limits {#limits}

It is worth noting that the buffer limit is 8 MiB and the tolerance is 1e-3. This mitigates the timeout; the underlying connection leak is not fixed.
