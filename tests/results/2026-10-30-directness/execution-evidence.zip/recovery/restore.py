"""Restore exact recorded files; default to a dry run and preserve later edits."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

WORK = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scope", choices=("source", "installed"), required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    record = json.loads((WORK / "recovery.json").read_text(encoding="utf-8"))[args.scope]
    root = Path(record["root"]).resolve()
    actions = []
    for relative, entry in record["files"].items():
        raw = root / relative
        parents = [raw, *raw.parents]
        if any(p.is_symlink() or (hasattr(p, "is_junction") and p.is_junction()) for p in parents):
            raise RuntimeError(f"Linked recovery target: {relative}")
        path = raw.resolve()
        if not path.is_relative_to(root):
            raise RuntimeError(f"Unsafe recovery target: {relative}")
        if digest(path) != entry["after_sha256"]:
            raise RuntimeError(f"Refusing to overwrite a later edit: {relative}")
        backup = (WORK / entry["before"]).resolve() if entry["before"] else None
        if backup and (not backup.is_relative_to(WORK) or digest(backup) != entry["before_sha256"]):
            raise RuntimeError(f"Recovery snapshot is missing or changed: {relative}")
        actions.append((path, backup))
    if args.apply:
        for path, backup in actions:
            if backup:
                path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(backup, path)
            else:
                # File-only deletion, after every absolute path and digest was checked.
                path.unlink()
    print(json.dumps({"scope": args.scope, "root": str(root), "files": len(actions),
                      "applied": args.apply}, ensure_ascii=True))


if __name__ == "__main__":
    main()
