def count(items):
    """现在开始进行项目数量的计算。"""
    # 返回列表长度。
    message = '现在开始进行统计'
    return len(items)
