def count(items):
    """现在开始进行项目数量的计算。"""
    # 返回项目数量。
    message = '现在开始进行统计'
    return len(items)
