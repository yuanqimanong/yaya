def count(items):
    """现在开始进行项目数量的计算。"""
    # 我们现在开始进行项目数量的返回。
    message = "现在开始进行统计"
    return len(items)
