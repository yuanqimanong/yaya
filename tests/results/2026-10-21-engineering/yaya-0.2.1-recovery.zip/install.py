"""Sync this reviewed candidate only; refuse changed installation or source."""
from pathlib import Path
import hashlib
import json
import os
import shutil

BASE = Path(__file__).resolve().parent
PLAN = json.loads((BASE / "manifest.json").read_text(encoding="utf-8"))
ROOT = Path(PLAN["root"])
DESTINATION = Path(PLAN["installed_root"])

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

current = {path.relative_to(DESTINATION).as_posix(): sha(path)
           for path in DESTINATION.rglob("*") if path.is_file()
           and "__pycache__" not in path.parts and path.suffix != ".pyc"}
if current != PLAN["installed_before_sha256"]:
    raise SystemExit("Installation changed since task start; refusing to overwrite customizations.")
for name, expected in PLAN["source_files"].items():
    if sha(ROOT / "core/yaya" / name) != expected:
        raise SystemExit("Candidate changed after recovery preparation: " + name)
written = []
try:
    for entry in PLAN["installed"]:
        name = entry["path"]
        if entry["before_sha256"] == entry["after_sha256"]:
            continue
        source = ROOT / "core/yaya" / name
        target = DESTINATION / name
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(target.name + ".yaya-candidate-tmp")
        if temporary.exists():
            raise RuntimeError("Temporary candidate already exists: " + str(temporary))
        with temporary.open("xb") as stream:
            stream.write(source.read_bytes())
        if sha(temporary) != entry["after_sha256"]:
            raise RuntimeError("Candidate copy changed: " + name)
        os.replace(temporary, target)
        written.append(entry)
    actual = {path.relative_to(DESTINATION).as_posix(): sha(path)
              for path in DESTINATION.rglob("*") if path.is_file()
              and "__pycache__" not in path.parts and path.suffix != ".pyc"}
    if actual != PLAN["source_files"]:
        raise RuntimeError("Installed files do not match candidate hashes.")
except Exception:
    for entry in reversed(written):
        target = DESTINATION / entry["path"]
        if target.exists() and sha(target) == entry["after_sha256"]:
            if entry["before"]:
                shutil.copyfile(BASE / entry["before"], target)
            else:
                target.unlink()
    raise
print(json.dumps({"status": "installed", "version": "0.2.1", "changed_files": len(written),
                  "runtime_files": len(actual), "destination": str(DESTINATION)}, ensure_ascii=True))
