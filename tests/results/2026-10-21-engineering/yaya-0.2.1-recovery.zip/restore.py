"""Preview rollback by default; --apply restores only this upgrade's exact files."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--scope", choices=("source", "installed"), required=True)
parser.add_argument("--apply", action="store_true")
args = parser.parse_args()
base = Path(__file__).resolve().parent
plan = json.loads((base / "manifest.json").read_text(encoding="utf-8"))
root = Path(plan["root"] if args.scope == "source" else plan["installed_root"]).resolve()
changes = [entry for entry in plan[args.scope] if entry["before_sha256"] != entry["after_sha256"]]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
for entry in changes:
    target = (root / entry["path"]).resolve()
    if not target.is_relative_to(root) or not target.is_file() or sha(target) != entry["after_sha256"]:
        raise SystemExit("Current file changed; manual merge required: " + str(target))
    if entry["before"] and sha(base / entry["before"]) != entry["before_sha256"]:
        raise SystemExit("Backup hash mismatch: " + entry["path"])
print(json.dumps({"scope": args.scope, "root": str(root), "files": [entry["path"] for entry in changes],
                  "action": "restore" if args.apply else "preview"}, ensure_ascii=True))
if args.apply:
    for entry in changes:
        target = root / entry["path"]
        if entry["before"]:
            shutil.copyfile(base / entry["before"], target)
        else:
            target.unlink()
